package cg.wbd.grandemonstration.exception;

public class DuplicateEmailException extends Exception {
}
